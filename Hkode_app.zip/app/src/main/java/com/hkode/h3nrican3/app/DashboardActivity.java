package com.hkode.h3nrican3.app;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import androidx.core.view.ViewCompat;

public class DashboardActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ImageView logo;
	private TextView textview1;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dashboard);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		logo = findViewById(R.id.logo);
		textview1 = findViewById(R.id.textview1);
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		ViewCompat.setTransitionName(logo, "app_logo");
		_ui_();
		_font_();
		_theme_();
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/outfit_bold.ttf"), 0);
	}
	
	
	public void _theme_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}